﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(Camera))]
[ExecuteInEditMode]
public class RayMarchCamera : SceneViewFilter
{
    [SerializeField]
    private Shader _shader;

    public Material _rayMarchMaterial
    {
        get {
            if (!_rayMarchMat && _shader)
            {
                _rayMarchMat = new Material(_shader);
                _rayMarchMat.hideFlags = HideFlags.HideAndDontSave;
            }
            return _rayMarchMat;
        }
    }

    private Material _rayMarchMat;

    public Camera _camera
    {
        get
        {
            if (!_cam)
            {
                _cam = GetComponent<Camera>();
            }
            return _cam;
        }
    }

    private Camera _cam;

    [Header("Light Settings")]
    public Transform _MainLight;
    public Vector3 _LightCol;
    public float _maxDistance;
    public float _LightIntensity;
   
    [Header("Shadow Settings")]
    [Range(0,4)]
    public float _ShadowIntensity;
    [Range(0, 128)]
    public float _ShadowPenumbra;
    public Vector2 _ShadowDistance;
    

    //temp
    [Header("Temp Shape Settings")]
    public Color _mainColor;
    public float _BoxRound;
    public float _BoxSphereSmooth;
    public float _SphereIntersectSmooth;
    public Vector4 _Sphere1;
    public Vector4 _Sphere2;
    public Vector4 _Box1;
    
    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (!_rayMarchMaterial)
        {
            Graphics.Blit(source, destination);
            return;
        }

        _rayMarchMaterial.SetVector("_LightDir", _MainLight ? _MainLight.forward : Vector3.down);
        _rayMarchMaterial.SetMatrix("_CamFrustrum", CamFrustrum(_camera));
        _rayMarchMaterial.SetMatrix("_CamToWorld", _camera.cameraToWorldMatrix);
        _rayMarchMaterial.SetFloat("_MaxDistance", _maxDistance);
        _rayMarchMaterial.SetFloat("_LightIntensity", _LightIntensity);
        _rayMarchMaterial.SetVector("_LightCol", _LightCol);
        _rayMarchMaterial.SetVector("_ShadowDistance", _ShadowDistance);
        _rayMarchMaterial.SetFloat("_ShadowIntensity", _ShadowIntensity);
        _rayMarchMaterial.SetFloat("_ShadowPenumbra", _ShadowPenumbra);


        //temp
        _rayMarchMaterial.SetFloat("_BoxRound", _BoxRound);
        _rayMarchMaterial.SetFloat("_BoxSphereSmooth", _BoxSphereSmooth);
        _rayMarchMaterial.SetFloat("_SphereIntersectSmooth", _SphereIntersectSmooth);
        _rayMarchMaterial.SetVector("_Sphere1", _Sphere1);
        _rayMarchMaterial.SetVector("_Sphere2", _Sphere2);
        _rayMarchMaterial.SetVector("_Box1", _Box1);
        _rayMarchMaterial.SetColor("_MainColor", _mainColor);

       

        RenderTexture.active = destination;
        _rayMarchMaterial.SetTexture("_MainTex", source);
        GL.PushMatrix();
        GL.LoadOrtho();
        _rayMarchMaterial.SetPass(0);
        GL.Begin(GL.QUADS);

        //BL
        GL.MultiTexCoord2(0, 0.0f, 0.0f);
        GL.Vertex3(0.0f, 0.0f, 3.0f);
        //BR
        GL.MultiTexCoord2(0, 1.0f, 0.0f);
        GL.Vertex3(1.0f, 0.0f, 2.0f);
        //TL
        GL.MultiTexCoord2(0, 1.0f, 1.0f);
        GL.Vertex3(1.0f, 1.0f, 1.0f);
        //TR
        GL.MultiTexCoord2(0, 0.0f, 1.0f);
        GL.Vertex3(0.0f, 1.0f, 0.0f);

        GL.End();
        GL.PopMatrix();

    }

    private Matrix4x4 CamFrustrum(Camera cam)
    {
        Matrix4x4 frustrum = Matrix4x4.identity;
        float fov = Mathf.Tan((_cam.fieldOfView * 0.5f) * Mathf.Deg2Rad);
        Vector3 goUp = Vector3.up * fov;
        Vector3 goRight = Vector3.right * fov * cam.aspect;
        Vector3 TL = (-Vector3.forward - goRight + goUp);
        Vector3 TR = (-Vector3.forward + goRight + goUp);
        Vector3 BR = (-Vector3.forward + goRight - goUp);
        Vector3 BL = (-Vector3.forward - goRight - goUp);

        frustrum.SetRow(0, TL);
        frustrum.SetRow(1, TR);
        frustrum.SetRow(2, BR);
        frustrum.SetRow(3, BL);

        return frustrum;
    }
}
